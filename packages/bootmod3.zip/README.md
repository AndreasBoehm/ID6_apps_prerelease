# Bootmod3 Suite for iDrive 6

Open the main page for map slots 1–4. Use Options for exhaust flap, Active Sound and burble presets. Map switching and burbles automatically identify a supported ROM and verify the result with DME readback. Exhaust flap and Active Sound send fixed commands. Burble presets require HSFZ. See HYBRID-AND-TUNING.md for details and the repository AgentReadMe for installation.
