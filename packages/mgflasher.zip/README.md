See HYBRID-AND-TUNING.md for supported readings, live controls and optional MG Flasher readback.
