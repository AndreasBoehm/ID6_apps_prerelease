# WarmDeck

The warm-up dashboard concept and original reference package were submitted by
a community contributor. This build uses the project's read-only diagnostics
and its own RHMI resources.

WarmDeck shows engine oil, coolant and transmission temperature data as
available. A warm-up estimate requires all three readings and a rising trend
for each fluid still below its target. Transmission temperature uses HSFZ.
